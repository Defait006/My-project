/**
 * Main JavaScript file for the Virtual Cafeteria application
 * Manages animations, UI interactions, and dynamic page behavior
 */

// Execute when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  // Set up core UI functionality
  setupPageTransitions();
  fixDuplicateElements();
  animateElements();
  enhanceModals();
  enhanceFormInteractions();
  setupAutoFadeAlerts();
  setupRecipeCalculations();
  
  // Initialize inventory page specific functionality if we're on that page
  initializeInventoryPage();
});

/**
 * Initialize inventory specific functionality
 * This function is called only on the inventory page
 */
function initializeInventoryPage() {
  console.log('Inventory page JavaScript initialized');
}

/**
 * Show a modal by ID - used by the onclick handlers in HTML
 * @param {string} modalId - The ID of the modal to show
 */
function showModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  
  modal.style.display = 'flex';
  
  // Add animation class with slight delay to ensure the display change has taken effect
  setTimeout(() => {
    modal.querySelector('.modal-content').classList.add('show');
  }, 10);
}

/**
 * Hide a modal by ID - used by the onclick handlers in HTML
 * @param {string} modalId - The ID of the modal to hide
 */
function hideModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  
  const modalContent = modal.querySelector('.modal-content');
  modalContent.classList.remove('show');
  
  // Add a delay for animation to complete before hiding
  setTimeout(() => {
    modal.style.display = 'none';
  }, 300);
}

/**
 * Populate the update modal with product information
 * @param {number} productId - The ID of the product
 * @param {string} productName - The name of the product
 * @param {number} currentQuantity - The current quantity of the product
 */
function updateProduct(productId, productName, currentQuantity) {
  // Set values in the update modal
  document.getElementById('updateProductId').value = productId;
  document.getElementById('updateProductName').textContent = productName;
  document.getElementById('update_quantity').value = currentQuantity;
  
  // Show the modal
  showModal('updateModal');
}

/**
 * Set up smooth page transitions between pages
 */
function setupPageTransitions() {
  // Create transition overlay if it doesn't exist
  if (!document.getElementById('page-transition')) {
    const overlay = document.createElement('div');
    overlay.id = 'page-transition';
    overlay.innerHTML = '<div class="transition-spinner"></div>';
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
      #page-transition {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.9);
        z-index: 9999;
        display: none;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
      }
      
      .transition-spinner {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        border: 3px solid #f3f3f3;
        border-top: 3px solid #3498db;
        animation: spin 1s linear infinite;
      }
      
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(overlay);
  }
  
  // Handle link clicks for page transitions
  document.addEventListener('click', e => {
    // Find closest anchor element if the click is on a child element
    const link = e.target.closest('a');
    
    // Only handle links that stay within our site and aren't special actions
    if (link && 
        !link.hasAttribute('data-no-transition') && 
        link.hostname === window.location.hostname && 
        link.getAttribute('target') !== '_blank' && 
        !link.getAttribute('href')?.startsWith('#') &&
        !link.getAttribute('href')?.startsWith('javascript:')) {
      
      e.preventDefault();
      const overlay = document.getElementById('page-transition');
      
      // Show transition
      overlay.style.display = 'flex';
      setTimeout(() => {
        overlay.style.opacity = '1';
      }, 10);
      
      // Navigate after animation
      setTimeout(() => {
        window.location = link.href;
      }, 400);
    }
  });
}

/**
 * Fix duplicate elements that might appear from AJAX loads
 */
function fixDuplicateElements() {
  const uniqueIds = {};
  
  document.querySelectorAll('[id]').forEach(element => {
    const id = element.getAttribute('id');
    
    if (uniqueIds[id]) {
      // Remove duplicates, keeping the first one
      element.remove();
    } else {
      uniqueIds[id] = true;
    }
  });
}

/**
 * Animate elements with data-animate attribute
 */
function animateElements() {
  const animatedElements = document.querySelectorAll('[data-animate]');
  
  // Set up intersection observer to trigger animations when elements come into view
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const element = entry.target;
        const animation = element.getAttribute('data-animate');
        
        element.classList.add('animated', animation);
        observer.unobserve(element);
      }
    });
  }, { threshold: 0.1 });
  
  // Observe each element
  animatedElements.forEach(element => {
    observer.observe(element);
  });
  
  // Add animation styles if they don't exist
  if (!document.getElementById('animation-styles')) {
    const style = document.createElement('style');
    style.id = 'animation-styles';
    style.textContent = `
      /* Base animation class */
      .animated {
        animation-duration: 0.8s;
        animation-fill-mode: both;
      }
      
      /* Fade In */
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      .fadeIn { animation-name: fadeIn; }
      
      /* Fade In Up */
      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translate3d(0, 30px, 0);
        }
        to {
          opacity: 1;
          transform: translate3d(0, 0, 0);
        }
      }
      .fadeInUp { animation-name: fadeInUp; }
      
      /* Fade In Down */
      @keyframes fadeInDown {
        from {
          opacity: 0;
          transform: translate3d(0, -30px, 0);
        }
        to {
          opacity: 1;
          transform: translate3d(0, 0, 0);
        }
      }
      .fadeInDown { animation-name: fadeInDown; }
      
      /* Slide In Right */
      @keyframes slideInRight {
        from {
          transform: translate3d(100%, 0, 0);
          visibility: visible;
        }
        to {
          transform: translate3d(0, 0, 0);
        }
      }
      .slideInRight { animation-name: slideInRight; }
      
      /* Pulse */
      @keyframes pulse {
        from {
          transform: scale3d(1, 1, 1);
        }
        50% {
          transform: scale3d(1.05, 1.05, 1.05);
        }
        to {
          transform: scale3d(1, 1, 1);
        }
      }
      .pulse { animation-name: pulse; }
    `;
    document.head.appendChild(style);
  }
}

/**
 * Enhance modal interactions for a better user experience
 */
function enhanceModals() {
  // Get all modal triggers
  const modalTriggers = document.querySelectorAll('[data-modal-target]');
  
  modalTriggers.forEach(trigger => {
    const targetId = trigger.getAttribute('data-modal-target');
    const modal = document.getElementById(targetId);
    
    if (!modal) return;
    
    // Create backdrop if it doesn't exist
    let backdrop = modal.querySelector('.modal-backdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.className = 'modal-backdrop';
      backdrop.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: -1;
        opacity: 0;
        transition: opacity 0.3s ease;
      `;
      modal.appendChild(backdrop);
    }
    
    // Add animation styles to modal
    modal.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
    
    // Setup open trigger
    trigger.addEventListener('click', e => {
      e.preventDefault();
      
      modal.style.display = 'flex';
      setTimeout(() => {
        modal.classList.add('active');
        backdrop.style.opacity = '1';
        
        // Add entrance animation based on placement
        if (modal.classList.contains('modal-top')) {
          modal.style.transform = 'translateY(0)';
        } else if (modal.classList.contains('modal-right')) {
          modal.style.transform = 'translateX(0)';
        } else if (modal.classList.contains('modal-bottom')) {
          modal.style.transform = 'translateY(0)';
        } else if (modal.classList.contains('modal-left')) {
          modal.style.transform = 'translateX(0)';
        } else {
          modal.style.opacity = '1';
          modal.style.transform = 'scale(1)';
        }
      }, 10);
    });
    
    // Setup close buttons
    const closeButtons = modal.querySelectorAll('[data-modal-close]');
    closeButtons.forEach(button => {
      button.addEventListener('click', e => {
        e.preventDefault();
        closeModal(modal);
      });
    });
    
    // Close on backdrop click
    backdrop.addEventListener('click', () => {
      closeModal(modal);
    });
    
    // Close on ESC key
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && modal.classList.contains('active')) {
        closeModal(modal);
      }
    });
  });
  
  // Add support for inline onclick modal handlers
  document.querySelectorAll('.modal').forEach(modal => {
    // Make sure we handle the close button clicks for all modals
    const closeButtons = modal.querySelectorAll('.close-button');
    closeButtons.forEach(button => {
      button.addEventListener('click', () => {
        hideModal(modal.id);
      });
    });
    
    // Add modal backdrop for click-outside-to-close functionality
    if (!modal.querySelector('.modal-backdrop')) {
      const backdrop = document.createElement('div');
      backdrop.className = 'modal-backdrop';
      backdrop.addEventListener('click', e => {
        if (e.target === backdrop) {
          hideModal(modal.id);
        }
      });
      modal.appendChild(backdrop);
    }
  });
}

/**
 * Close modal with animation - used by enhanceModals
 * @param {HTMLElement} modal - The modal element to close
 */
function closeModal(modal) {
  const backdrop = modal.querySelector('.modal-backdrop');
  
  // Apply the appropriate closing animation based on modal placement
  if (modal.classList.contains('modal-top')) {
    modal.style.transform = 'translateY(-100%)';
  } else if (modal.classList.contains('modal-right')) {
    modal.style.transform = 'translateX(100%)';
  } else if (modal.classList.contains('modal-bottom')) {
    modal.style.transform = 'translateY(100%)';
  } else if (modal.classList.contains('modal-left')) {
    modal.style.transform = 'translateX(-100%)';
  } else {
    modal.style.opacity = '0';
    modal.style.transform = 'scale(0.9)';
  }
  
  if (backdrop) {
    backdrop.style.opacity = '0';
  }
  
  // Hide modal after animation completes
  setTimeout(() => {
    modal.classList.remove('active');
    modal.style.display = 'none';
  }, 300);
}

/**
 * Enhance form interactions with floating labels and validation
 */
function enhanceFormInteractions() {
  // Add floating labels
  const formInputs = document.querySelectorAll('.form-group input, .form-group textarea, .form-group select');
  
  formInputs.forEach(input => {
    // Check if input already has value
    if (input.value.trim() !== '') {
      input.classList.add('has-value');
    }
    
    // Add event listeners for focus and blur
    input.addEventListener('focus', () => {
      input.parentElement.classList.add('focused');
    });
    
    input.addEventListener('blur', () => {
      input.parentElement.classList.remove('focused');
      if (input.value.trim() !== '') {
        input.classList.add('has-value');
      } else {
        input.classList.remove('has-value');
      }
    });
  });
  
  // Form validation with visual feedback
  const forms = document.querySelectorAll('form[data-validate]');
  
  forms.forEach(form => {
    form.addEventListener('submit', function(e) {
      let isValid = true;
      
      // Clear previous errors
      form.querySelectorAll('.error-message').forEach(error => error.remove());
      form.querySelectorAll('.is-invalid').forEach(field => field.classList.remove('is-invalid'));
      
      // Validate required fields
      form.querySelectorAll('[required]').forEach(field => {
        if (field.value.trim() === '') {
          isValid = false;
          showError(field, 'This field is required');
        }
      });
      
      // Validate email fields
      form.querySelectorAll('input[type="email"]').forEach(field => {
        if (field.value.trim() !== '' && !isValidEmail(field.value)) {
          isValid = false;
          showError(field, 'Please enter a valid email address');
        }
      });
      
      if (!isValid) {
        e.preventDefault();
        
        // Scroll to first error with animation
        const firstError = form.querySelector('.is-invalid');
        if (firstError) {
          window.scrollTo({
            top: firstError.getBoundingClientRect().top + window.pageYOffset - 100,
            behavior: 'smooth'
          });
        }
      } else {
        // Show success animation if validation passes
        const submitBtn = form.querySelector('[type="submit"]');
        if (submitBtn) {
          submitBtn.classList.add('btn-success-animation');
          setTimeout(() => {
            submitBtn.classList.remove('btn-success-animation');
          }, 1500);
        }
      }
    });
  });
  
  /**
   * Show error message for a form field
   * @param {HTMLElement} field - The form field
   * @param {string} message - The error message
   */
  function showError(field, message) {
    field.classList.add('is-invalid');
    
    // Create error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
      color: #dc3545;
      font-size: 0.8rem;
      margin-top: 5px;
      animation: fadeIn 0.3s ease;
    `;
    
    field.parentElement.appendChild(errorDiv);
  }
  
  /**
   * Validate email format
   * @param {string} email - The email to validate
   * @returns {boolean} - True if email is valid
   */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
}

/**
 * Setup auto-dismissing alerts with progress bars
 */
function setupAutoFadeAlerts() {
  const alerts = document.querySelectorAll('.alert[data-auto-dismiss]');
  
  alerts.forEach(alert => {
    const dismissTime = alert.getAttribute('data-auto-dismiss') || 5000;
    
    // Add progress bar if not present
    if (!alert.querySelector('.alert-progress')) {
      const progressBar = document.createElement('div');
      progressBar.className = 'alert-progress';
      progressBar.style.cssText = `
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background-color: rgba(255, 255, 255, 0.5);
        width: 100%;
        transform-origin: left;
        animation: alertProgress ${dismissTime}ms linear forwards;
      `;
      alert.appendChild(progressBar);
      alert.style.position = 'relative';
      alert.style.overflow = 'hidden';
    }
    
    // Auto dismiss after time
    setTimeout(() => {
      dismissAlert(alert);
    }, dismissTime);
    
    // Add dismiss button if not present
    if (!alert.querySelector('.close')) {
      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'close';
      closeBtn.innerHTML = '&times;';
      closeBtn.style.cssText = `
        position: absolute;
        top: 0;
        right: 0;
        padding: 0.75rem 1.25rem;
        background: transparent;
        border: 0;
        font-size: 1.25rem;
        cursor: pointer;
      `;
      
      closeBtn.addEventListener('click', () => {
        dismissAlert(alert);
      });
      
      alert.appendChild(closeBtn);
    }
  });
  
  // Add keyframe for progress bar if not exists
  if (!document.getElementById('alert-keyframes')) {
    const style = document.createElement('style');
    style.id = 'alert-keyframes';
    style.textContent = `
      @keyframes alertProgress {
        0% { transform: scaleX(1); }
        100% { transform: scaleX(0); }
      }
      
      @keyframes alertOut {
        0% { 
          opacity: 1;
          transform: translateX(0);
        }
        100% { 
          opacity: 0;
          transform: translateX(40px);
        }
      }
    `;
    document.head.appendChild(style);
  }
  
  /**
   * Dismiss an alert with animation
   * @param {HTMLElement} alert - The alert element to dismiss
   */
  function dismissAlert(alert) {
    alert.style.animation = 'alertOut 0.5s forwards';
    setTimeout(() => {
      alert.style.height = alert.offsetHeight + 'px';
      alert.style.overflow = 'hidden';
      
      setTimeout(() => {
        alert.style.height = '0';
        alert.style.padding = '0';
        alert.style.margin = '0';
        alert.style.border = '0';
        
        setTimeout(() => {
          alert.remove();
        }, 300);
      }, 10);
    }, 500);
  }
}

/**
 * Handle recipe calculations and serving size adjustments
 */
function setupRecipeCalculations() {
  const recipeServings = document.querySelectorAll('.recipe-servings');
  
  recipeServings.forEach(servingControl => {
    const decreaseBtn = servingControl.querySelector('.decrease-servings');
    const increaseBtn = servingControl.querySelector('.increase-servings');
    const servingInput = servingControl.querySelector('.serving-count');
    const recipeId = servingControl.getAttribute('data-recipe-id');
    
    if (!decreaseBtn || !increaseBtn || !servingInput) return;
    
    // Handle decrease servings
    decreaseBtn.addEventListener('click', () => {
      let count = parseInt(servingInput.value);
      if (count > 1) {
        servingInput.value = count - 1;
        updateIngredientAmounts(recipeId, count - 1);
      }
    });
    
    // Handle increase servings
    increaseBtn.addEventListener('click', () => {
      let count = parseInt(servingInput.value);
      servingInput.value = count + 1;
      updateIngredientAmounts(recipeId, count + 1);
    });
    
    // Handle direct input
    servingInput.addEventListener('change', () => {
      let count = parseInt(servingInput.value);
      if (isNaN(count) || count < 1) {
        servingInput.value = 1;
        count = 1;
      }
      updateIngredientAmounts(recipeId, count);
    });
  });
  
  /**
   * Update ingredient amounts based on serving size
   * @param {string} recipeId - The ID of the recipe
   * @param {number} newServings - The new number of servings
   */
  function updateIngredientAmounts(recipeId, newServings) {
    const ingredientList = document.querySelector(`.ingredient-list[data-recipe-id="${recipeId}"]`);
    if (!ingredientList) return;
    
    const originalServings = parseInt(ingredientList.getAttribute('data-original-servings'));
    if (isNaN(originalServings)) return;
    
    const ratio = newServings / originalServings;
    
    // Update each ingredient amount
    ingredientList.querySelectorAll('.ingredient-amount').forEach(amountEl => {
      const originalAmount = parseFloat(amountEl.getAttribute('data-original-amount'));
      if (isNaN(originalAmount)) return;
      
      const newAmount = originalAmount * ratio;
      
      // Format the display amount based on value
      let displayAmount;
      if (newAmount < 0.1) {
        displayAmount = newAmount.toFixed(2);
      } else if (newAmount < 1) {
        displayAmount = newAmount.toFixed(1);
      } else if (newAmount.toFixed(0) == newAmount) {
        displayAmount = newAmount.toFixed(0);
      } else {
        displayAmount = newAmount.toFixed(1);
      }
      
      // Animate the change
      amountEl.style.transition = 'transform 0.3s ease';
      amountEl.style.transform = 'scale(1.2)';
      setTimeout(() => {
        amountEl.textContent = displayAmount;
        setTimeout(() => {
          amountEl.style.transform = 'scale(1)';
        }, 10);
      }, 300);
    });
  }
}

// Add necessary modal styles if not already present
document.addEventListener('DOMContentLoaded', () => {
  if (!document.getElementById('modal-styles')) {
    const style = document.createElement('style');
    style.id = 'modal-styles';
    style.textContent = `
      .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        z-index: 1000;
      }
      
      .modal-content {
        background-color: white;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        max-width: 500px;
        width: 100%;
        transform: scale(0.8);
        opacity: 0;
        transition: transform 0.3s, opacity 0.3s;
      }
      
      .modal-content.show {
        transform: scale(1);
        opacity: 1;
      }
      
      .modal-backdrop {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
      }
    `;
    document.head.appendChild(style);
  }
});