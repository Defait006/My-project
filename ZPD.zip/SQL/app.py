from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from datetime import datetime
from contextlib import contextmanager
import re

app = Flask(__name__)
app.secret_key = "supersecretkey"  # In production, use a secure random key

# English to Latvian weekday translations
WEEKDAYS = {
    "Monday": "Pirmdiena", "Tuesday": "Otrdiena", "Wednesday": "Trešdiena",
    "Thursday": "Ceturtdiena", "Friday": "Piektdiena", "Saturday": "Sestdiena",
    "Sunday": "Svētdiena"
}

@contextmanager
def get_db_connection():
    """Context manager for database connections"""
    conn = sqlite3.connect("cafeteria.db", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def get_categories():
    """Get all product categories from the database"""
    with get_db_connection() as conn:
        return conn.execute("SELECT * FROM Categories ORDER BY category_name").fetchall()

def format_quantity(amount):
    """Format quantity in g or kg for display"""
    return f"{amount/1000:.1f} kg" if amount >= 1000 else f"{amount} g"

def get_formatted_recipes(day_filter=None):
    """Get formatted recipes with optional day filter"""
    with get_db_connection() as conn:
        # Build query based on presence of day filter
        base_query = """
            SELECT r.recipe_id, r.recipe_name, p.product_name, rp.quantity_needed
            FROM Recipes r
            LEFT JOIN RecipeProducts rp ON r.recipe_id = rp.recipe_id
            LEFT JOIN Products p ON rp.product_id = p.product_id
        """
        
        if day_filter:
            query = f"{base_query} WHERE r.recipe_name LIKE ? ORDER BY r.recipe_name, p.product_name"
            recipes_data = conn.execute(query, (f"{day_filter}%",)).fetchall()
        else:
            query = f"""{base_query} 
                ORDER BY 
                    CASE 
                        WHEN r.recipe_name LIKE 'Pirmdiena%' THEN 1
                        WHEN r.recipe_name LIKE 'Otrdiena%' THEN 2
                        WHEN r.recipe_name LIKE 'Trešdiena%' THEN 3
                        WHEN r.recipe_name LIKE 'Ceturtdiena%' THEN 4
                        WHEN r.recipe_name LIKE 'Piektdiena%' THEN 5
                        ELSE 6
                    END,
                    r.recipe_name, p.product_name
            """
            recipes_data = conn.execute(query).fetchall()
    
    # Group and format recipes data
    formatted_recipes = {}
    for row in recipes_data:
        recipe_id = row['recipe_id']
        if recipe_id not in formatted_recipes:
            formatted_recipes[recipe_id] = {
                'recipe_id': recipe_id,
                'recipe_name': row['recipe_name'],
                'ingredients': []
            }
        if row['product_name']:
            formatted_recipes[recipe_id]['ingredients'].append({
                'product_name': row['product_name'],
                'quantity_needed': row['quantity_needed']
            })
    
    return list(formatted_recipes.values())

def get_inventory(category_id=None):
    """Get inventory with optional category filter"""
    with get_db_connection() as conn:
        base_query = """
            SELECT c.category_name, p.product_name, i.quantity, p.product_id
            FROM Categories c
            JOIN Products p ON c.category_id = p.category_id
            JOIN Inventory i ON p.product_id = i.product_id
        """
        
        if category_id:
            query = f"{base_query} WHERE c.category_id = ? ORDER BY c.category_name, p.product_name"
            inventory_data = conn.execute(query, (category_id,)).fetchall()
        else:
            query = f"{base_query} ORDER BY c.category_name, p.product_name"
            inventory_data = conn.execute(query).fetchall()
    
    # Group inventory by category
    categorized_inventory = {}
    for item in inventory_data:
        category = item['category_name']
        if category not in categorized_inventory:
            categorized_inventory[category] = []
        
        categorized_inventory[category].append({
            'name': item['product_name'],
            'quantity': item['quantity'],
            'id': item['product_id']
        })
    
    return categorized_inventory

@app.template_filter('slugify')
def slugify(value):
    """Convert a string into a URL-friendly slug."""
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    return re.sub(r'[-\s]+', '-', value)

@app.route("/")
def index():
    """Handle the home page"""
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Determine current weekday
    weekday_num = datetime.now().weekday()
    current_weekday = datetime.now().strftime("%A")
    weekday_lv = WEEKDAYS[current_weekday]
    
    # Default to Monday's menu on weekends
    menu_weekday = "Pirmdiena" if weekday_num >= 5 else weekday_lv
    is_weekend = weekday_num >= 5
    
    with get_db_connection() as conn:
        # Get menu items for the current weekday
        menu = conn.execute("""
            SELECT recipe_id, recipe_name
            FROM Recipes
            WHERE recipe_name LIKE ?
            ORDER BY recipe_name
        """, (f"{menu_weekday}%",)).fetchall()
        
        # Get system stats for dashboard
        stats = conn.execute("""
            SELECT 
                (SELECT COUNT(*) FROM Products) as product_count,
                (SELECT COUNT(*) FROM Recipes) as recipe_count,
                (SELECT COUNT(*) FROM Inventory WHERE quantity < 100) as low_stock_count
        """).fetchone()
    
    # Get calculation results from session and clear them
    calculation_results = {}
    for key in list(session.keys()):
        if key.startswith('calculation_'):
            calculation_id = key.split('_')[1]
            calculation_results[calculation_id] = session.pop(key)
    
    return render_template("index.html",
                         username=session['username'],
                         menu=menu,
                         weekday=weekday_lv,
                         is_weekend=is_weekend,
                         stats=stats,
                         current_year=datetime.now().year,
                         calculation_results=calculation_results)

@app.route("/add_recipe", methods=["GET", "POST"])
def add_recipe():
    """Handle adding a new recipe"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    # Initialize session data if needed
    session.setdefault('recipe_ingredients', [])
    session.setdefault('recipe_name', "")
    
    if request.method == "POST":
        action = request.form.get('action', '')
        
        # Handle adding ingredient 
        if action == 'add_ingredient':
            ingredient = request.form.get('new_ingredient', '').strip()
            quantity = request.form.get('new_quantity', '').strip()
            recipe_name = request.form.get('recipe_name', '').strip()
            
            session['recipe_name'] = recipe_name
            
            if not (ingredient and quantity):
                flash("Lūdzu ievadiet sastāvdaļu un daudzumu", "error")
                return redirect(url_for("add_recipe"))
                
            try:
                quantity_val = int(quantity)
                if quantity_val <= 0:
                    flash("Daudzumam jābūt lielākam par 0", "error")
                    return redirect(url_for("add_recipe"))
                    
                # Check if ingredient already exists
                existing_ingredients = [item['name'] for item in session['recipe_ingredients']]
                if ingredient in existing_ingredients:
                    flash(f"Sastāvdaļa '{ingredient}' jau ir pievienota receptei", "error")
                    return redirect(url_for("add_recipe"))
                    
                # Add new ingredient to session
                session['recipe_ingredients'].append({
                    'name': ingredient,
                    'quantity': quantity_val
                })
                flash(f"Sastāvdaļa '{ingredient}' pievienota", "success")
            except ValueError:
                flash("Nederīgs daudzums", "error")
                
            return redirect(url_for("add_recipe"))
            
        # Handle saving the recipe
        elif action == 'save_recipe':
            recipe_name = request.form.get('recipe_name', '').strip()
            
            # Validate recipe name
            if not recipe_name:
                flash("Lūdzu ievadiet receptes nosaukumu", "error")
                return redirect(url_for("add_recipe"))
            
            valid_prefixes = ["Pirmdiena -", "Otrdiena -", "Trešdiena -", "Ceturtdiena -", "Piektdiena -"]
            if not any(recipe_name.startswith(prefix) for prefix in valid_prefixes):
                flash("Receptes nosaukumam jāsākas ar nedēļas dienu (piem., 'Pirmdiena - Zupa')", "error")
                return redirect(url_for("add_recipe"))
            
            if not session['recipe_ingredients']:
                flash("Lūdzu pievienojiet vismaz vienu sastāvdaļu", "error")
                return redirect(url_for("add_recipe"))
            
            with get_db_connection() as conn:
                try:
                    conn.execute("BEGIN TRANSACTION")
                    
                    # Insert recipe
                    conn.execute("INSERT INTO Recipes (recipe_name) VALUES (?)", (recipe_name,))
                    recipe_id = conn.execute(
                        "SELECT recipe_id FROM Recipes WHERE recipe_name = ?",
                        (recipe_name,)
                    ).fetchone()['recipe_id']
                    
                    # Insert ingredients
                    for ingredient in session['recipe_ingredients']:
                        product_name = ingredient['name']
                        quantity_val = ingredient['quantity']
                        
                        product_id = conn.execute(
                            "SELECT product_id FROM Products WHERE product_name = ?",
                            (product_name,)
                        ).fetchone()
                        
                        if not product_id:
                            conn.rollback()
                            flash(f"Sastāvdaļa '{product_name}' nav atrasta datubāzē", "error")
                            return redirect(url_for("add_recipe"))
                            
                        conn.execute("""
                            INSERT INTO RecipeProducts (recipe_id, product_id, quantity_needed)
                            VALUES (?, ?, ?)
                        """, (recipe_id, product_id['product_id'], quantity_val))
                    
                    conn.commit()
                    flash("Recepte veiksmīgi pievienota!", "success")
                    
                    # Clear session data
                    session.pop('recipe_ingredients', None)
                    session.pop('recipe_name', None)
                    
                    return redirect(url_for("recipes"))
                    
                except sqlite3.IntegrityError:
                    conn.rollback()
                    flash("Recepte ar šādu nosaukumu jau eksistē", "error")
                except Exception as e:
                    conn.rollback()
                    flash(f"Kļūda: {str(e)}", "error")
    
    # GET request - show form
    with get_db_connection() as conn:
        products = conn.execute("SELECT product_name FROM Products ORDER BY product_name").fetchall()
    
    return render_template("add_recipe.html", 
                         products=products,
                         ingredients=session.get('recipe_ingredients', []),
                         recipe_name=session.get('recipe_name', ''),
                         current_year=datetime.now().year)

@app.route("/recipes")
def recipes():
    """Display all recipes"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    # Get weekday filter from query parameters
    day_filter = request.args.get('day')
    
    # Get formatted recipes with optional day filter
    recipes_list = get_formatted_recipes(day_filter)
    
    return render_template("recipes.html", 
                         recipes=recipes_list,
                         current_year=datetime.now().year)

@app.route("/inventory")
def inventory():
    """Display inventory management page"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    category_id = request.args.get('category', type=int)
    
    # Get inventory with optional category filter
    categorized_inventory = get_inventory(category_id)
    
    with get_db_connection() as conn:
        # Get categories for filter tabs
        categories = conn.execute("SELECT * FROM Categories ORDER BY category_name").fetchall()
    
    return render_template("inventory.html", 
                         inventory=categorized_inventory,
                         categories=categories,
                         current_year=datetime.now().year)

@app.route("/reports")
def reports():
    """Display reports page with low stock alerts"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    with get_db_connection() as conn:
        stats = conn.execute("SELECT COUNT(*) as total_products FROM Products").fetchone()
        
        low_stock = conn.execute("""
            SELECT p.product_name, i.quantity, c.category_name
            FROM Inventory i
            JOIN Products p ON i.product_id = p.product_id
            JOIN Categories c ON p.category_id = c.category_id
            WHERE i.quantity < 100
            ORDER BY i.quantity ASC
        """).fetchall()
        
        # Get unique categories for filtering
        categories = conn.execute("""
            SELECT DISTINCT c.category_name
            FROM Categories c
            JOIN Products p ON c.category_id = p.category_id
            JOIN Inventory i ON p.product_id = i.product_id
            WHERE i.quantity < 100
            ORDER BY c.category_name
        """).fetchall()
        
        categories = [c['category_name'] for c in categories]
    
    return render_template("reports.html", 
                         low_stock=low_stock,
                         stats=stats,
                         categories=categories,
                         current_year=datetime.now().year)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Handle user login"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        
        with get_db_connection() as conn:
            user = conn.execute(
                "SELECT * FROM Users WHERE username = ? AND password = ?", 
                (username, password)
            ).fetchone()
        
        if user:
            session['username'] = username
            return redirect(url_for('index'))
        flash('Nepareizs lietotājvārds vai parole', 'error')
    return render_template("login.html")

@app.route("/logout")
def logout():
    """Handle user logout"""
    for key in ['username', 'recipe_ingredients', 'recipe_name']:
        session.pop(key, None)
    flash('Jūs esat izgājis no sistēmas', 'info')
    return redirect(url_for('login'))

@app.route("/recipe/<int:recipe_id>")
def recipe_detail(recipe_id):
    """Display detailed view of a recipe"""
    if 'username' not in session:
        return redirect(url_for('login'))
    
    with get_db_connection() as conn:
        recipe = conn.execute("""
            SELECT r.recipe_id, r.recipe_name, 
                   p.product_name, rp.quantity_needed, 
                   c.category_name
            FROM Recipes r
            JOIN RecipeProducts rp ON r.recipe_id = rp.recipe_id
            JOIN Products p ON rp.product_id = p.product_id
            JOIN Categories c ON p.category_id = c.category_id
            WHERE r.recipe_id = ?
        """, (recipe_id,)).fetchall()
        
        if not recipe:
            flash('Recepte nav atrasta', 'error')
            return redirect(url_for('recipes'))
        
        recipe_data = {
            'id': recipe[0]['recipe_id'],
            'name': recipe[0]['recipe_name'],
            'ingredients': [{
                'product_name': row['product_name'],
                'quantity': row['quantity_needed'],
                'category': row['category_name']
            } for row in recipe]
        }
        
    return render_template("recipe_detail.html", 
                          recipe=recipe_data,
                          current_year=datetime.now().year)

@app.route("/add_product", methods=["POST"])
def add_product_route():
    """Handle adding a new product to inventory"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    product_name = request.form["product_name"]
    quantity = int(request.form["quantity"])
    category_id = int(request.form["category_id"])
    
    with get_db_connection() as conn:
        try:
            conn.execute("BEGIN TRANSACTION")
            conn.execute(
                "INSERT INTO Products (product_name, category_id) VALUES (?, ?)",
                (product_name, category_id)
            )
            product_id = conn.execute(
                "SELECT product_id FROM Products WHERE product_name = ?", 
                (product_name,)
            ).fetchone()['product_id']
            conn.execute(
                "INSERT INTO Inventory (product_id, quantity) VALUES (?, ?)",
                (product_id, quantity)
            )
            conn.commit()
            flash("Produkts veiksmīgi pievienots!", "success")
        except sqlite3.IntegrityError:
            conn.rollback()
            flash("Produkts ar šādu nosaukumu jau eksistē", "error")
    
    return redirect(url_for("inventory"))

@app.route("/delete_multiple_products", methods=["POST"])
def delete_multiple_products_route():
    """Route to delete multiple products at once"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    product_ids = request.form.getlist('product_ids[]')
    
    if not product_ids:
        flash('Nederīgi dati. Nav izvēlēti produkti dzēšanai.', 'error')
        return redirect(url_for('inventory'))
    
    try:
        with get_db_connection() as conn:
            conn.execute("BEGIN TRANSACTION")
            
            deleted_count = 0
            skipped_count = 0
            products_in_recipes = []
            
            for product_id in product_ids:
                # Check if product is used in any recipes
                recipe_usage = conn.execute(
                    "SELECT COUNT(*) as count FROM RecipeProducts WHERE product_id = ?",
                    (product_id,)
                ).fetchone()
                
                # Get product name for message
                product = conn.execute(
                    "SELECT product_name FROM Products WHERE product_id = ?", 
                    (product_id,)
                ).fetchone()
                
                if not product:
                    continue
                
                product_name = product['product_name']
                
                # Skip products used in recipes
                if recipe_usage and recipe_usage['count'] > 0:
                    skipped_count += 1
                    products_in_recipes.append(product_name)
                    continue
                
                # Delete from inventory first (foreign key constraint)
                conn.execute("DELETE FROM Inventory WHERE product_id = ?", (product_id,))
                conn.execute("DELETE FROM Products WHERE product_id = ?", (product_id,))
                
                deleted_count += 1
            
            conn.commit()
            
            # Show appropriate message based on results
            if deleted_count > 0 and skipped_count == 0:
                flash(f'{deleted_count} produkti veiksmīgi dzēsti!', 'success') if deleted_count > 1 else flash('1 produkts veiksmīgi dzēsts!', 'success')
            elif deleted_count > 0 and skipped_count > 0:
                flash(f'{deleted_count} produkti dzēsti. {skipped_count} produkti izlaisti, jo tie tiek izmantoti receptēs.', 'info')
                if products_in_recipes:
                    recipes_list = ", ".join(products_in_recipes[:3])
                    if len(products_in_recipes) > 3:
                        recipes_list += f" un vēl {len(products_in_recipes) - 3}"
                    flash(f'Produkti receptēs: {recipes_list}', 'info')
            elif deleted_count == 0 and skipped_count > 0:
                flash(f'Nevarēja dzēst izvēlētos produktus, jo tie tiek izmantoti receptēs.', 'error')
                
    except Exception as e:
        flash(f'Kļūda dzēšot produktus: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route("/delete_product/<int:product_id>", methods=["POST"])
def delete_product(product_id):
    """Handle deleting a single product"""
    if "username" not in session:
        return redirect(url_for("login"))
        
    with get_db_connection() as conn:
        try:
            # Check if product is used in any recipes
            recipe_usage = conn.execute(
                "SELECT COUNT(*) as count FROM RecipeProducts WHERE product_id = ?",
                (product_id,)
            ).fetchone()
            
            # Get product name for message
            product = conn.execute(
                "SELECT product_name FROM Products WHERE product_id = ?", 
                (product_id,)
            ).fetchone()
            
            if not product:
                flash("Produkts nav atrasts", "error")
                return redirect(url_for("inventory"))
                
            product_name = product['product_name']
            
            # Skip products used in recipes
            if recipe_usage and recipe_usage['count'] > 0:
                flash(f"Nevar dzēst produktu '{product_name}', jo tas tiek izmantots receptēs", "error")
                return redirect(url_for("inventory"))
                
            conn.execute("BEGIN TRANSACTION")
            conn.execute("DELETE FROM Inventory WHERE product_id = ?", (product_id,))
            conn.execute("DELETE FROM Products WHERE product_id = ?", (product_id,))
            
            conn.commit()
            flash(f"Produkts '{product_name}' veiksmīgi dzēsts", "success")
            
        except Exception as e:
            conn.rollback()
            flash(f"Kļūda dzēšot produktu: {str(e)}", "error")
            
    return redirect(url_for("inventory"))

@app.route("/update_inventory", methods=["POST"])
def update_inventory_route():
    """Update a single product's quantity"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    product_id = int(request.form["product_id"])
    quantity = int(request.form["quantity"])
    
    with get_db_connection() as conn:
        conn.execute(
            "UPDATE Inventory SET quantity = ? WHERE product_id = ?",
            (quantity, product_id)
        )
        conn.commit()
    
    flash("Daudzums veiksmīgi atjaunināts!", "success")
    return redirect(url_for("inventory"))

@app.route("/delete_recipe_ingredient/<int:recipe_id>/<int:product_id>", methods=["GET"])
def delete_recipe_ingredient(recipe_id, product_id):
    """Handle deleting an ingredient from a recipe."""
    if "username" not in session:
        return redirect(url_for("login"))
    
    with get_db_connection() as conn:
        try:
            conn.execute("BEGIN TRANSACTION")
            
            # Get product name for message
            product = conn.execute(
                "SELECT product_name FROM Products WHERE product_id = ?", 
                (product_id,)
            ).fetchone()
            
            if not product:
                flash("Sastāvdaļa nav atrasta", "error")
                return redirect(url_for("edit_recipe", recipe_id=recipe_id))
            
            product_name = product['product_name']
            
            # Delete the specific product from the recipe
            conn.execute("""
                DELETE FROM RecipeProducts 
                WHERE recipe_id = ? AND product_id = ?
            """, (recipe_id, product_id))
            
            conn.commit()
            flash(f"Sastāvdaļa '{product_name}' veiksmīgi izdzēsta no receptes!", "success")
        except Exception as e:
            conn.rollback()
            flash(f"Kļūda dzēšot sastāvdaļu: {str(e)}", "error")
    
    return redirect(url_for("edit_recipe", recipe_id=recipe_id))    

@app.route("/delete_recipe/<int:recipe_id>", methods=["POST"])
def delete_recipe(recipe_id):
    """Delete a recipe and its ingredients"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    with get_db_connection() as conn:
        try:
            conn.execute("BEGIN TRANSACTION")
            
            
            conn.execute("DELETE FROM RecipeProducts WHERE recipe_id = ?", (recipe_id,))
            
            
            conn.execute("DELETE FROM Recipes WHERE recipe_id = ?", (recipe_id,))
            
            conn.commit()
            flash("Recepte veiksmīgi izdzēsta!", "success")
        except Exception as e:
            conn.rollback()
            flash(f"Kļūda dzēšot recepti: {str(e)}", "error")
    
    return redirect(url_for("recipes"))

@app.route("/register", methods=["GET", "POST"])
def register():
    """Handle user registration"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        repeat_password = request.form["repeat_password"]
        
        # Validation checks
        if password != repeat_password:
            flash("Paroles nesakrīt!", "error")
            return redirect(url_for("register"))
        
        if len(password) < 8:
            flash("Parolei jābūt vismaz 8 simbolus garai", "error")
            return redirect(url_for("register"))
        
        # Check for uppercase, lowercase, and digit
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        
        if not (has_upper and has_lower and has_digit):
            missing = []
            if not has_upper: missing.append("lielais burts")
            if not has_lower: missing.append("mazais burts") 
            if not has_digit: missing.append("cipars")
            flash(f"Parolei jāsatur: {', '.join(missing)}", "error")
            return redirect(url_for("register"))
        
        with get_db_connection() as conn:
            try:
                conn.execute(
                    "INSERT INTO Users (username, password) VALUES (?, ?)",
                    (username, password)
                )
                conn.commit()
                flash("Konts veiksmīgi izveidots!", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Lietotājvārds jau eksistē", "error")
    
    return render_template("register.html")    

@app.route("/update_multiple_products", methods=["POST"])
def update_multiple_products_route():
    """Update multiple products with the same quantity value"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    product_ids = request.form.getlist('product_ids[]')
    bulk_quantity = request.form.get('bulk_quantity')
    
    if not product_ids or not bulk_quantity:
        flash('Nederīgi dati. Lūdzu mēģiniet vēlreiz.', 'error')
        return redirect(url_for('inventory'))
    
    try:
        quantity = int(bulk_quantity)
        
        with get_db_connection() as conn:
            conn.execute("BEGIN TRANSACTION")
            
            for product_id in product_ids:
                conn.execute(
                    "UPDATE Inventory SET quantity = ? WHERE product_id = ?",
                    (quantity, product_id)
                )
            
            conn.commit()
        
        count = len(product_ids)
        flash(f'{count} produkti veiksmīgi atjaunināti!' if count > 1 else '1 produkts veiksmīgi atjaunināts!', 'success')
            
    except ValueError:
        flash('Lūdzu ievadiet derīgu daudzumu.', 'error')
    except Exception as e:
        flash(f'Kļūda atjauninot produktus: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route("/edit_recipe/<int:recipe_id>", methods=["GET", "POST"])
def edit_recipe(recipe_id):
    """Handler for editing recipe ingredients quantities."""
    if "username" not in session:
        return redirect(url_for("login"))
    
    with get_db_connection() as conn:
        # Get recipe details
        recipe = conn.execute(
            "SELECT recipe_id, recipe_name FROM Recipes WHERE recipe_id = ?", 
            (recipe_id,)
        ).fetchone()
        
        if not recipe:
            flash("Recepte nav atrasta", "error")
            return redirect(url_for("recipes"))
        
        # Get current ingredients
        ingredients = conn.execute("""
            SELECT rp.product_id, p.product_name, rp.quantity_needed
            FROM RecipeProducts rp
            JOIN Products p ON rp.product_id = p.product_id
            WHERE rp.recipe_id = ?
            ORDER BY p.product_name
        """, (recipe_id,)).fetchall()
    
    # Handle POST request (form submission for quantity updates only)
    if request.method == "POST" and request.form.get('form_action') == 'update_quantities':
        try:
            with get_db_connection() as conn:
                conn.execute("BEGIN TRANSACTION")
                
                # Update each ingredient quantity
                for ingredient in ingredients:
                    product_id = ingredient['product_id']
                    new_quantity = request.form.get(f"quantity_{product_id}")
                    
                    if new_quantity:
                        try:
                            quantity_val = int(new_quantity)
                            if quantity_val <= 0:
                                conn.rollback()
                                flash(f"Daudzumam jābūt lielākam par 0 (Sastāvdaļa: {ingredient['product_name']})", "error")
                                return redirect(url_for("edit_recipe", recipe_id=recipe_id))
                                
                            conn.execute("""
                                UPDATE RecipeProducts 
                                SET quantity_needed = ? 
                                WHERE recipe_id = ? AND product_id = ?
                            """, (quantity_val, recipe_id, product_id))
                        except ValueError:
                            conn.rollback()
                            flash(f"Nederīgs daudzums sastāvdaļai '{ingredient['product_name']}'", "error")
                            return redirect(url_for("edit_recipe", recipe_id=recipe_id))
                
                conn.commit()
                flash("Sastāvdaļu daudzumi veiksmīgi atjaunināti!", "success")
                return redirect(url_for("recipes"))
                
        except Exception as e:
            flash(f"Kļūda: {str(e)}", "error")
            return redirect(url_for("edit_recipe", recipe_id=recipe_id))
    
    # For GET request, render the edit form
    return render_template("edit_recipe_quantities.html", 
                          recipe=recipe, 
                          ingredients=ingredients,
                          current_year=datetime.now().year)

@app.route("/calculate_ingredients", methods=["POST"])
def calculate_ingredients():
    """Calculate recipe ingredients based on number of people"""
    if "username" not in session:
        return redirect(url_for("login"))
    
    # Check referrer to determine return page
    referer = request.headers.get('Referer', '')
    is_from_index = '/index' in referer or referer.endswith('/')
    
    try:
        recipe_id = int(request.form["recipe_id"])
        people = int(request.form["people"])
        
        if people <= 0:
            flash("Personu skaitam jābūt lielākam par 0", "error")
            return redirect(url_for("index" if is_from_index else "recipes"))
            
        with get_db_connection() as conn:
            # Get recipe name
            recipe_name = conn.execute(
                "SELECT recipe_name FROM Recipes WHERE recipe_id = ?", 
                (recipe_id,)
            ).fetchone()
            
            if not recipe_name:
                flash("Recepte nav atrasta", "error")
                return redirect(url_for("index" if is_from_index else "recipes"))
                
            recipe_name = recipe_name["recipe_name"]
            
            # Get ingredients
            ingredients = conn.execute("""
                SELECT p.product_name, rp.quantity_needed, i.quantity, p.product_id
                FROM RecipeProducts rp
                JOIN Products p ON rp.product_id = p.product_id
                JOIN Inventory i ON p.product_id = i.product_id
                WHERE rp.recipe_id = ?
            """, (recipe_id,)).fetchall()
            
            result = []
            result.append(f"🍳 Recepte: {recipe_name} ({people} personām)")
            
            if not ingredients:
                result.append("⚠️ Šai receptei nav pievienotas sastāvdaļas!")
                
                if is_from_index:
                    session[f'calculation_{recipe_id}'] = result
                    return redirect(url_for("index"))
                
                return render_template("recipes.html", 
                                    calculation_result=result,
                                    recipes=get_formatted_recipes(),
                                    current_year=datetime.now().year)
            
            # Check if we have enough of all ingredients
            has_all_ingredients = True
            
            try:
                conn.execute("BEGIN TRANSACTION")
                
                for ingredient in ingredients:
                    product_name = ingredient["product_name"]
                    base_quantity = ingredient["quantity_needed"]
                    stock_quantity = ingredient["quantity"]
                    product_id = ingredient["product_id"]
                    
                    total_needed = base_quantity * people
                    
                    # Format quantities for display
                    display_total = format_quantity(total_needed)
                    display_stock = format_quantity(stock_quantity)
                    
                    # Check if enough in stock
                    if total_needed > stock_quantity:
                        has_all_ingredients = False
                        result.append(
                            f"⚠️ Nav pietiekami {product_name}. " + 
                            f"Nepieciešams: {display_total}, " + 
                            f"Pieejams: {display_stock}"
                        )
                    else:
                        result.append(f"✅ {product_name}: {display_total}")
                        
                        # Update inventory
                        conn.execute("""
                            UPDATE Inventory 
                            SET quantity = quantity - ? 
                            WHERE product_id = ?
                        """, (total_needed, product_id))
                
                # Commit only if we have all ingredients
                if has_all_ingredients:
                    conn.commit()
                    result.append("✅ Noliktava atjaunināta!")
                else:
                    conn.rollback()
                    result.append("⚠️ Noliktava nav atjaunināta, jo nepietiek sastāvdaļu!")
                
            except Exception as e:
                conn.rollback()
                result.append(f"⚠️ Kļūda aprēķinos: {str(e)}")
            
            # Store results and redirect based on source page
            if is_from_index:
                session[f'calculation_{recipe_id}'] = result
                return redirect(url_for("index"))
            
            return render_template("recipes.html", 
                                calculation_result=result,
                                recipes=get_formatted_recipes(),
                                current_year=datetime.now().year)
        
    except ValueError:
        flash("Lūdzu ievadiet derīgu personu skaitu", "error")
    except Exception as e:
        flash(f"Kļūda aprēķinot sastāvdaļas: {str(e)}", "error")
        
    return redirect(url_for("index" if is_from_index else "recipes"))


if __name__ == "__main__":
    app.run(debug=True)