import sqlite3
from contextlib import contextmanager

@contextmanager
def db_connection():
    """Context manager for database connections"""
    conn = sqlite3.connect('cafeteria.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        yield conn, cursor
    finally:
        conn.close()

def create_tables():
    """Create all database tables"""
    with db_connection() as (conn, cursor):
        # Create tables with foreign key relationships in correct order
        tables = [
            """
            CREATE TABLE IF NOT EXISTS Categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_name TEXT NOT NULL UNIQUE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS Products (
                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_name TEXT NOT NULL UNIQUE,
                category_id INTEGER NOT NULL,
                FOREIGN KEY (category_id) REFERENCES Categories(category_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS Inventory (
                product_id INTEGER PRIMARY KEY,
                quantity INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (product_id) REFERENCES Products(product_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS Users (
                user_id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS Recipes (
                recipe_id INTEGER PRIMARY KEY,
                recipe_name TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS RecipeProducts (
                recipe_id INTEGER,
                product_id INTEGER,
                quantity_needed INTEGER,
                FOREIGN KEY (recipe_id) REFERENCES Recipes(recipe_id),
                FOREIGN KEY (product_id) REFERENCES Products(product_id)
            )
            """
        ]
        
        for table_sql in tables:
            cursor.execute(table_sql)
        
        conn.commit()

def get_category_id(category_name):
    """Get category ID by name"""
    with db_connection() as (conn, cursor):
        cursor.execute('SELECT category_id FROM Categories WHERE category_name = ?', (category_name,))
        result = cursor.fetchone()
        return result['category_id'] if result else None

def populate_categories():
    """Add default categories to the database"""
    categories = [
        "Piena produkti", "Gaļa", "Dārzeņi", 
        "Graudi/Cietes produkti", "Augļi", "Citas sastāvdaļas"
    ]
    
    with db_connection() as (conn, cursor):
        for category in categories:
            cursor.execute('INSERT OR IGNORE INTO Categories (category_name) VALUES (?)', (category,))
        conn.commit()

def add_product(product_name, category_id, quantity):
    """Add a new product with initial inventory quantity"""
    with db_connection() as (conn, cursor):
        try:
            # Use transaction
            cursor.execute(
                'INSERT INTO Products (product_name, category_id) VALUES (?, ?)',
                (product_name, category_id)
            )
            
            product_id = cursor.lastrowid
            cursor.execute(
                'INSERT INTO Inventory (product_id, quantity) VALUES (?, ?)',
                (product_id, quantity)
            )
            
            conn.commit()
            return True, "Produkts veiksmīgi pievienots"
        except sqlite3.IntegrityError:
            conn.rollback()
            return False, "Produkts ar šādu nosaukumu jau eksistē"

def populate_initial_products():
    """Add initial products to the database with inventory amounts"""
    populate_categories()
    
    # Define products by category with initial quantities
    products_by_category = {
        "Piena produkti": {
            "Krējums 20%": 500,
            "Piens 2.5% (skolas)": 1000,
            "Piens 2%": 1000,
            "Kefīrs 2.5%": 500,
            "Jogurts 8%": 500,
            "Siers": 500
        },
        "Gaļa": {
            "Malta cūkgaļa": 800,
            "Cūkgaļa": 800,
            "Vistas gaļa": 800,
            "Gaļa kāpostu tīteņiem": 800
        },
        "Dārzeņi": {
            "Skābenes": 200,
            "Svaigi kāposti": 500,
            "Skābēti kāposti": 500,
            "Burkāni": 500,
            "Kartupeļi": 1000,
            "Sīpoli": 300,
            "Tomāti": 500,
            "Bietes": 500
        },
        "Graudi/Cietes produkti": {
            "Griķi": 1000,
            "Makaroni": 1000,
            "Kviešu pārslas": 1000,
            "Rupjmaize": 1000
        },
        "Augļi": {
            "Āboli": 500,
            "Banāni": 300,
            "Persiki": 300,
            "Mango": 300
        },
        "Citas sastāvdaļas": {
            "Eļļa": 500,
            "Garšvielas": 200,
            "Tēja": 500,
            "Ūdens": 1000,
            "Ciete": 200
        }
    }
    
    with db_connection() as (conn, cursor):
        for category_name, products in products_by_category.items():
            category_id = get_category_id(category_name)
            
            for product_name, quantity in products.items():
                try:
                    # Add product to Products table
                    cursor.execute(
                        'INSERT INTO Products (product_name, category_id) VALUES (?, ?)',
                        (product_name, category_id)
                    )
                    
                    # Add to inventory
                    product_id = cursor.lastrowid
                    cursor.execute(
                        'INSERT INTO Inventory (product_id, quantity) VALUES (?, ?)',
                        (product_id, quantity)
                    )
                except sqlite3.IntegrityError:
                    # Skip if product already exists
                    continue
                    
        conn.commit()

def add_recipe(recipe_name, ingredients):
    """Add a recipe with its ingredients to the database"""
    with db_connection() as (conn, cursor):
        cursor.execute('INSERT INTO Recipes (recipe_name) VALUES (?)', (recipe_name,))
        recipe_id = cursor.lastrowid
        
        for product_name, quantity_needed in ingredients.items():
            cursor.execute('SELECT product_id FROM Products WHERE product_name = ?', (product_name,))
            product = cursor.fetchone()
            
            if product:
                product_id = product['product_id']
                cursor.execute(
                    'INSERT INTO RecipeProducts (recipe_id, product_id, quantity_needed) VALUES (?, ?, ?)', 
                    (recipe_id, product_id, quantity_needed)
                )
                
        conn.commit()

def populate_recipes():
    """Add initial recipes to the database"""
    # Define recipes with ingredients and quantities
    recipes = {
        "Pirmdiena - Skābeņu zupa": {
            "Skābenes": 200, "Vistas gaļa": 100, "Kartupeļi": 100,
            "Sīpoli": 50, "Burkāni": 50, "Krējums 20%": 50
        },
        "Pirmdiena - Maltās gaļas mērce": {
            "Malta cūkgaļa": 200, "Sīpoli": 50, "Tomāti": 100, "Garšvielas": 10
        },
        "Pirmdiena - Vārīti griķi": {
            "Griķi": 200
        },
        "Pirmdiena - Svaigu kāpostu salāti": {
            "Svaigi kāposti": 200, "Burkāni": 100, "Eļļa": 50
        },
        "Pirmdiena - Kefīrs": {
            "Kefīrs 2.5%": 200
        },
        "Otrdiena - Borščs": {
            "Svaigi kāposti": 200, "Bietes": 100, "Burkāni": 50,
            "Kartupeļi": 100, "Krējums 20%": 50
        },
        "Otrdiena - Kviešu pārslas ar augļiem": {
            "Kviešu pārslas": 200, "Āboli": 100, "Mango": 50
        },
        "Otrdiena - Piens": {
            "Piens 2.5% (skolas)": 200
        },
        "Trešdiena - Dārzeņu zupa": {
            "Vistas gaļa": 200, "Burkāni": 100, "Kartupeļi": 100, "Sīpoli": 50
        },
        "Trešdiena - Makaroni ar sieru": {
            "Makaroni": 200, "Siers": 100
        },
        "Trešdiena - Burkānu salāti": {
            "Burkāni": 200, "Āboli": 100, "Eļļa": 50
        },
        "Ceturtdiena - Skābētu kāpostu zupa": {
            "Skābēti kāposti": 200, "Malta cūkgaļa": 100, "Burkāni": 50, 
            "Sīpoli": 50, "Krējums 20%": 50
        },
        "Ceturtdiena - Griķu biezputra": {
            "Griķi": 200, "Siers": 50
        },
        "Ceturtdiena - Augļu kokteilis": {
            "Banāni": 100, "Āboli": 100, "Persiki": 100, "Jogurts 8%": 200
        },
        "Piektdiena - Dārzeņu zupa": {
            "Burkāni": 100, "Kartupeļi": 100, "Sīpoli": 50, "Vistas gaļa": 100
        },
        "Piektdiena - Kartupeļi ar kotletēm": {
            "Kartupeļi": 300, "Malta cūkgaļa": 200, "Svaigi kāposti": 100,
            "Burkāni": 50, "Eļļa": 30
        },
        "Piektdiena - Augļu tēja": {
            "Tēja": 20
        }
    }
    
    for recipe_name, ingredients in recipes.items():
        add_recipe(recipe_name, ingredients)

def get_products_by_category():
    """Get all products grouped by categories with inventory quantities"""
    with db_connection() as (conn, cursor):
        cursor.execute('''
            SELECT c.category_name, p.product_name, i.quantity
            FROM Products p
            JOIN Categories c ON p.category_id = c.category_id
            JOIN Inventory i ON p.product_id = i.product_id
            ORDER BY c.category_name, p.product_name
        ''')
        return cursor.fetchall()

def validate_user(username, password):
    """Check if username and password are valid"""
    with db_connection() as (conn, cursor):
        cursor.execute('SELECT * FROM Users WHERE username = ? AND password = ?', 
                     (username, password))
        return cursor.fetchone() is not None

def add_user(username, password):
    """Add a new user to the database"""
    with db_connection() as (conn, cursor):
        try:
            cursor.execute('INSERT INTO Users (username, password) VALUES (?, ?)', 
                         (username, password))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

def update_inventory(product_id, quantity):
    """Update the quantity of a product in inventory"""
    with db_connection() as (conn, cursor):
        cursor.execute('UPDATE Inventory SET quantity = ? WHERE product_id = ?', 
                     (quantity, product_id))
        conn.commit()

def get_recipes():
    """Get all recipes from the database"""
    with db_connection() as (conn, cursor):
        cursor.execute('SELECT recipe_id, recipe_name FROM Recipes')
        return cursor.fetchall()

def check_inventory(recipe_id):
    """Check if all ingredients for a recipe are available in inventory"""
    with db_connection() as (conn, cursor):
        cursor.execute('''
            SELECT p.product_name, rp.quantity_needed, i.quantity
            FROM RecipeProducts rp
            JOIN Products p ON rp.product_id = p.product_id
            JOIN Inventory i ON p.product_id = i.product_id
            WHERE rp.recipe_id = ?
        ''', (recipe_id,))
        
        insufficient = []
        for row in cursor.fetchall():
            product_name, quantity_needed, quantity_available = row
            if quantity_needed > quantity_available:
                insufficient.append(f"Not enough {product_name}")
                
        return insufficient if insufficient else ["All ingredients are available"]

def initialize_database():
    """Initialize the database with tables and sample data"""
    create_tables()
    populate_categories()
    populate_initial_products()
    populate_recipes()

if __name__ == "__main__":
    initialize_database()